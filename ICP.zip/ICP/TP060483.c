#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<string.h>

int password();

void createrecord();
void checkrecord();
void editrecord();
void editpassword();
void deleterecord();

struct record

{
    char time[6];
    char name[30];
    char place[25];
    char duration[10];
    char note[500];
} ;

int main()                                                              //Main menu 
{
    int ch;
    printf("\n\n\t######### WELCOME ##########\n");
    printf("\t# PERSONAL TASK MANAGEMENT #\n");         
    printf("\t############################");
    while(1)
    {
        printf("\n\n\t\t### MAIN MENU ###");
        printf("\n\n\t[1]\tCREATE RECORD");
        printf("\n\t[2]\tVIEW RECORD");
        printf("\n\t[3]\tEDIT RECORD");                               //Display Menu
        printf("\n\t[4]\tDELETE RECORD");
        printf("\n\t[5]\tEDIT PASSWORD");
        printf("\n\t[6]\tEXIT\t");
        printf("\n\n\tENTER YOUR CHOICE | ");                         //Enter user choice
        scanf("%d",&ch);
        switch(ch)
        {
        case 1:
            createrecord();
            break;
        case 2:
            checkrecord();
            break;
        case 3:
            editrecord();
            break;
        case 4:
            deleterecord();
            break;
        case 5:
            editpassword();
            break;
        case 6:

            printf("\n\n\tHAVE A NICE DAY!!! ");
            getch();
            exit(0);
        default:
            printf("\n\tVALUE ERROR\n\tPRESS ANY KEY TO TRY AGAIN");
            getch();
            break;
        }
        system("cls");
    }
    return 0;
}

void createrecord()                                                        //It adds new records
{
    system("cls");
    FILE *fp ;
    char another = 'Y' ,time[10];
    struct record e ;
    char filename[15];
    int choice;
    printf("\n\n\t####################\n");
    printf("\t#  TO THE ADD MENU #");              
    printf("\n\t####################\n\n");
    printf("\n\n\tENTER DATE OF RECORD [D-M-Y] | ");                 
    fflush(stdin);                             
    gets(filename);                                                    
    fp = fopen (filename, "ab+" ) ;             
    if ( fp == NULL )                          
    {                                          
        fp=fopen(filename,"wb+");              
        if(fp==NULL)                           
        {                                      
            printf("\n\tVALUE ERROR\n\tPRESS ANY KEY TO TRY AGAIN");                        
            getch();                           
            return ;                           
        }                                      
    }                                          
    while ( another == 'Y'|| another=='y' )    
    {                                          
        choice=0;                              
        fflush(stdin);                         
        printf ( "\n\tENTER TIME [H : M] | ");
        scanf("%s",time);
        rewind(fp);
        while(fread(&e,sizeof(e),1,fp)==1)
        {
            if(strcmp(e.time,time)==0)
            {
                printf("\n\tTHE RECORD ALREADY EXISTS.\n");
                choice=1;
            }
        }
        if(choice==0)
        {
            strcpy(e.time,time);
            printf("\n\tENTER NAME       | ");
            fflush(stdin);
            gets(e.name);
            fflush(stdin);
            printf("\tENTER PLACE      | ");
            gets(e.place);                                          //save recods
            fflush(stdin);
            printf("\tENTER DURATION   | ");
            gets(e.duration);
            fflush(stdin);
            printf("\tNOTE             | ");
            gets(e.note);
            fwrite ( &e, sizeof ( e ), 1, fp ) ;
            printf("\n\tRECORD IS ADDED\n");
        }
        printf ( "\n\tADD ANOTHER RECORD [ YES / NO ] | " ) ;
        fflush ( stdin ) ;
        another = getchar( ) ;
    }
    fclose ( fp ) ;
    printf("\n\n\tPRESS ANY KEY TO EXIT");
    getch();
}

void checkrecord()                                                       //It veiws saved records
{   
    FILE *fpte ;
    system("cls");
    struct record customer ;
    char time[6],choice,filename[14];
    int ch;
    printf("\n\n\t####################\n");
    printf("\t# THE VIEWING MENU #");
    printf("\n\t####################\n\n");
    choice=password();
    if(choice!=0)
    {
        return ;
    }
    do
    {
        printf("\n\tENTER THE DATE OF RECORD TO BE VIEWED [D-M-Y] | ");           //It finds records for view them
        fflush(stdin);                                                                      
        gets(filename);
        fpte = fopen ( filename, "rb" ) ;
        if ( fpte == NULL )                                                     
        {
            puts ( "\n\tTHE RECORD DOES NOT EXIST\n" ) ;
            printf("\tPRESS ANY KEY TO EXIT");
            getch();
            return ;
        }
        system("cls");
        printf("\n\tHOW WOULD LIKE TO VIEW\n");
        printf("\n\t1.WHOLE RECORD OF THE DAY");
        printf("\n\t2.RECORD OF FIX TIME");
        printf("\n\tENTER CHOICE | ");
        scanf("%d",&ch);
        switch(ch)
        {
        case 1:
            printf("\n\tTHE RECORD DETAILS %s ",filename);
            while ( fread ( &customer, sizeof ( customer ), 1, fpte ) == 1 )
            {
                printf("\n");
                printf("\n\tTIME         | %s",customer.time);
                printf("\n\tMEETING WITH | %s",customer.name);
                printf("\n\tMEETING AT   | %s",customer.place);
                printf("\n\tDURATION     | %s",customer.duration);
                printf("\n\tNOTE         | %s",customer.note);
                printf("\n");
            }
            break;
        case 2:
            fflush(stdin);
            printf("\n\tENTER TIME [H : M] | ");
            gets(time);
            while ( fread ( &customer, sizeof ( customer ), 1, fpte ) == 1 )
            {
                if(strcmp(customer.time,time)==0)
                {
                    printf("\n\tTHE RECORD IS | ");
                    printf("\n\tTIME          | %s",customer.time);
                    printf("\n\tMEETING WITH  | %s",customer.name);
                    printf("\n\tMEETING AT    | %s",customer.place);
                    printf("\n\tDUARATION     | %s",customer.duration);
                    printf("\n\tNOTE          | %s",customer.note);
                }
            }
            break;
        default:
            printf("\n\tYOU TYPED SOMETHING ELSE\n");
            break;
        }
        printf("\n\n\tWOULD YOU LIKE TO CONTINUE VIEWING [ YES / NO ] | ");
        fflush(stdin);
        scanf("%c",&choice);
    }
    while(choice=='Y'||choice=='y');
    fclose ( fpte ) ;
    return ;
}

void editrecord()                                                       //It edits record from list
{
    system("cls");
    FILE *fpte ;
    struct record customer ;
    char time[6],choice,filename[14];
    int num,count=0;
    printf("\n\n\t####################\n");
    printf("\t# THE EDITING MENU #");
    printf("\n\t####################\n\n");
    choice=password();
    if(choice!=0)
    {
        return ;
    }
    do
    {
        printf("\n\tENTER THE DATE OF RECORD TO BE EDITED [D-M-Y] | ");
        fflush(stdin);
        gets(filename);
        printf("\n\tENTER TIME [H : M] | ");
        gets(time);
        fpte = fopen ( filename, "rb+" ) ;
        if ( fpte == NULL )
        {
            printf( "\n\tRECORD DOES NOT EXISTS" ) ;
            printf("\n\tPRESS ANY KEY TO GO BACK");
            getch();
            return;
        }
        while ( fread ( &customer, sizeof ( customer ), 1, fpte ) == 1 )
        {
            if(strcmp(customer.time,time)==0)
            {
                printf("\n\tOLD RECORD WAS AS");
                printf("\n\tTIME         | %s",customer.time);
                printf("\n\tMEETING WITH | %s",customer.name);
                printf("\n\tMEETING AT   | %s",customer.place);
                printf("\n\tDURATION     | %s",customer.duration);
                printf("\n\tNOTE         | %s",customer.note);
                printf("\n\n\t\tWHAT WOULD YOU LIKE TO EDIT");
                printf("\n\t1.TIME");
                printf("\n\t2.MEETING PERSON");
                printf("\n\t3.MEETING PLACE");
                printf("\n\t4.DURATION");
                printf("\n\t5.NOTE");
                printf("\n\t6.WHOLE RECORD");
                printf("\n\t7.GO BACK TO MAIN MENU");
                do
                {
                    printf("\n\tENTER YOUR CHOICE | ");
                    fflush(stdin);
                    scanf("%d",&num);
                    fflush(stdin);
                    switch(num)
                    {
                    case 1:
                        printf("\n\tENTER NEW TIME [H : M]   | ");
                        gets(customer.time);
                        break;
                    case 2:
                        printf("\n\tENTER NEW MEETING PERSON | ");
                        gets(customer.name);
                        break;
                    case 3:
                        printf("\n\tENTER NEW MEETING PLACE  | ");
                        gets(customer.place);                
                        break;
                    case 4:                                  
                        printf("\n\tENTER NEW DURATION       | ");
                        gets(customer.duration);             
                        break;
                    case 5:                                  
                        printf("\n\tENTER NEW NOTE           | ");
                        gets(customer.note);
                        break;
                    case 6:
                        printf("\n\tNEW TIME [H : M]   | ");
                        gets(customer.time);
                        printf("\n\tNEW MEETING PERSON | ");
                        gets(customer.name);
                        printf("\n\tNEW MEETING PLACE  | ");
                        gets(customer.place);
                        printf("\n\tNEW DURATION       | ");
                        gets(customer.duration);
                        printf("\n\tNEW NOTE           | ");
                        gets(customer.note);
                        break;
                    case 7:
                        printf("\n\tPRESS ANY KEY TO GO BACK\n");
                        getch();
                        return ;
                        break;
                    default:
                        printf("\n\tYOU TYPED SOMETHING ELSE | TRY AGAIN\n");
                        break;
                    }
                }
                while(num<1||num>8);
                fseek(fpte,-sizeof(customer),SEEK_CUR);
                fwrite(&customer,sizeof(customer),1,fpte);
                fseek(fpte,-sizeof(customer),SEEK_CUR);
                fread(&customer,sizeof(customer),1,fpte);
                choice=5;
                break;
            }
        }
        if(choice==5)
        {
            system("cls");
            printf("\n\tEDITING COMPLETED\n");
            printf("\t####################\n");
            printf("\t# THE NEW RECORD IS # \n");
            printf("\t####################\n");
            printf("\n\tTIME         | %s",customer.time);
            printf("\n\tMEETING WITH | %s",customer.name);
            printf("\n\tMEETING AT   | %s",customer.place);
            printf("\n\tDURATION     | %s",customer.duration);
            printf("\n\tNOTE         | %s",customer.note);
            fclose(fpte);
            printf("\n\n\tWOULD YOU LIKE TO EDIT ANOTHER RECORD [ YES / NO ] | ");
            scanf("%c",&choice);
            count++;
        }
        else
        {
            printf("\n\tTHE RECORD DOES NOT EXIST\n");
            printf("\n\tWOULD YOU LIKE TO TRY AGAIN [ YES / NO ] | ");
            scanf("%c",&choice);
        }
    }
    while(choice=='Y'||choice=='y');
    fclose ( fpte ) ;
    if(count==1)
        printf("\n\t%d FILE IS EDITED\n",count);
    else if(count>1)
        printf("\n\t%d FILES ARE EDITED\n",count);
    else
        printf("\n\tNO FILES EDITED\n");
    printf("\tPRESS ENTER TO EXIT EDITING MENU");
    getch();
}

int password()                                                          //It ask passwords (Access for menu)                                                   
{
    char pass[15]= {0},check[15]= {0},ch;
    FILE *fpp;
    int i=0,j;
    printf("\t### PLEASE ENTER THE PASSWORD ###");
    printf("\n\t### ONLY THREE TRIALS ARE ALLOWED ###");
    for(j=0; j<3; j++)
    {
        i=0;
        printf("\n\n\tENTER THE PASSWORD | ");
        pass[0]=getch();
        while(pass[i]!='\r')
        {
            if(pass[i]=='\b')
            {
                i--;
                printf("\b");
                printf(" ");
                printf("\b");
                pass[i]=getch();
            }
            else
            {
                printf("*");
                i++;
                pass[i]=getch();
            }
        }
        pass[i]='\0';
        fpp=fopen("SE","r");
        if (fpp==NULL)
        {
            printf("\n\tERROR WITH THE SYSTEM FILE [FILE MISSING]\n");
            getch();
            return 1;
        }
        else
            i=0;
        while(1)
        {
            ch=fgetc(fpp);
            if(ch==EOF)
            {
                check[i]='\0';
                break;
            }
            check[i]=ch-5;
            i++;
        }
        if(strcmp(pass,check)==0)
        {
            printf("\n\n\tACCESS GRANTED!!!\n");
            return 0;
        }
        else
        {
            printf("\n\n\tWRONG PASSWORD!!!\n\n\tACCESS DENIED!!!\n");
        }
    }
    getch();
    return 1;
}

void editpassword()                                                     //it changes the Admin password. Deffaoult password is 1 
{
    system("cls");
    printf("\n");
    char pass[15]= {0},confirm[15]= {0},ch;
    int choice,i,check;
    FILE *fp;
    fp=fopen("SE","rb");
    if(fp==NULL)
    {
        fp=fopen("SE","wb");
        if(fp==NULL)
        {
            printf("\tSYSTEM ERROR");
            getch();
            return ;
        }
        fclose(fp);
        printf("\n\tSYSTEM RESTORED\n\t PRESS ENTER TO CHANGE PASSWORD\n\n");
        getch();
    }
    fclose(fp);
    check=password();
    if(check==1)
    {
        return ;
    }
    do
    {
        if(check==0)
        {
            i=0;
            choice=0;
            printf("\n\n\tENTER THE NEW PASSWORD | ");
            fflush(stdin);
            pass[0]=getch();
            while(pass[i]!='\r')
            {
                if(pass[i]=='\b')
                {
                    i--;
                    printf("\b");
                    printf(" ");
                    printf("\b");
                    pass[i]=getch();
                }
                else
                {
                    printf("*");
                    i++;
                    pass[i]=getch();
                }
            }
            pass[i]='\0';
            i=0;
            printf("\n\tCONFIRM PASSWORD       | ");
            confirm[0]=getch();
            while(confirm[i]!='\r')
            {
                if(confirm[i]=='\b')
                {
                    i--;
                    printf("\b");
                    printf(" ");
                    printf("\b");
                    confirm[i]=getch();
                }
                else
                {
                    printf("*");
                    i++;
                    confirm[i]=getch();
                }
            }
            confirm[i]='\0';
            if(strcmp(pass,confirm)==0)
            {
                fp=fopen("SE","wb");
                if(fp==NULL)
                {
                    printf("\n\tSYSTEM ERROR");
                    getch();
                    return ;
                }
                i=0;
                while(pass[i]!='\0')
                {
                    ch=pass[i];
                    putc(ch+5,fp);
                    i++;
                }
                putc(EOF,fp);
                fclose(fp);
            }
            else
            {
                printf("\n\tTHE NEW PASSWORD DOES NOT MATCH");
                choice=1;
            }
        }
    }
    while(choice==1);
    printf("\n\n\tPASSWORD CHANGED\n\n\tPRESS ANY KEY TO GO BACK");
    getch();
}

void deleterecord()                                                     //It deletes record from list
{
    system("cls");
    FILE *fp,*fptr ;
    struct record file ;
    char filename[15],another = 'Y' ,time[10];;
    int choice,check;
    printf("\n\n\t###################\n");
    printf("\t# TO DELETE MENU #");
    printf("\n\t###################\n\n");
    check = password();
    if(check==1)
    {
        return ;
    }
    while ( another == 'Y' )
    {
        printf("\n\n\tHOW WOULD YOU LIKE TO DELETE");
        printf("\n\n\t[1]\tDELETE WHOLE DAY RECORDS\t\t");
        printf("\n\t[2]\tDELETE A PARTICULAR RECORD BY TIME");
        do
        {
            printf("\n\tENTER CHOICE | ");
            scanf("%d",&choice);
            switch(choice)
            {
            case 1:
                printf("\n\tENTER THE DATE OF RECORD TO BE DELETED [D-M-Y] | ");
                fflush(stdin);
                gets(filename);
                fp = fopen (filename, "wb" ) ;
                if ( fp == NULL )
                {
                    printf("\n\tTHE FILE DOES NOT EXISTS");
                    printf("\n\tPRESS ANY KEY TO GO BACK");
                    getch();
                    return ;
                }
                fclose(fp);
                remove(filename);
                printf("\n\tDELETED SUCCESFULLY\n");
                break;
            case 2:
                printf("\n\tENTER THE DATE OF RECORD [D-M-Y] | ");
                fflush(stdin);
                gets(filename);
                fp = fopen (filename, "rb" ) ;
                if ( fp == NULL )
                {
                    printf("\n\tTHE FILE DOES NOT EXISTS");
                    printf("\n\tPRESS ANY KEY TO GO BACK");
                    getch();
                    return ;
                }
                fptr=fopen("temp","wb");
                if(fptr==NULL)
                {
                    printf("\n\tSYSTEM ERROR");
                    printf("\n\tPRESS ANY KEY TO GO BACK");
                    getch();
                    return ;
                }
                printf("\n\tENTER THE TIME OF RECORD TO BE DELETED [H : M] | ");
                fflush(stdin);
                gets(time);
                while(fread(&file,sizeof(file),1,fp)==1)
                {
                    if(strcmp(file.time,time)!=0)
                        fwrite(&file,sizeof(file),1,fptr);
                }
                fclose(fp);
                fclose(fptr);
                remove(filename);
                rename("temp",filename);
                printf("\n\tDELETED SUCCESFULLY");
                break;
            default:
                printf("\n\tYOU ENTERED WRONG CHOICE");
                break;
            }
        }
        while(choice<1||choice>2);
        printf("\n\tDO YOU LIKE TO DELETE ANOTHER RECORD [ YES / NO ] | ");
        fflush(stdin);
        scanf("%c",&another);
    }
    printf("\n\n\tPRESS ANY KEY TO EXIT");
    getch();
}